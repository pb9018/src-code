package com.infy.ekart.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.DealsForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealsForToday;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.DealsForTodayRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;

@Service
@Transactional
public class DealsForTodayServiceImpl implements DealsForTodayService {
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private SellerRepository sellerRepository;
	
	@Autowired
	private DealsForTodayRepository deals;

	@Override
	public List<ProductDTO> getProductsWithoutDeals(String sellerEmailId, Integer pageNo) throws EKartException {
		
		Pageable p = PageRequest.of(pageNo,10);
		
		List<Product> productList = deals.getproductsWithoutDealsForToday(sellerEmailId, p);
		List<ProductDTO> productDTOList = new ArrayList<>();
		if(productList==null || productList.isEmpty()) {
			throw new EKartException("DealsForToday.PRODUCTS_NOT_FOUND");
		}
		for(Product product : productList) {
			ProductDTO productDTO = new ProductDTO();
			productDTO.setBrand(product.getBrand());
			productDTO.setCategory(product.getCategory());
			productDTO.setDescription(product.getDescription());
			productDTO.setDiscount(product.getDiscount());
			productDTO.setName(product.getName());
			productDTO.setPrice(product.getPrice());
			productDTO.setProductId(product.getProductId());
			productDTO.setQuantity(product.getQuantity());
			productDTO.setSellerEmailId(sellerEmailId);
			productDTOList.add(productDTO);

		}
		return productDTOList;	
		}


	@Override
	public Integer addProductsTonewDeal(DealsForTodayDTO dealsForToday) throws EKartException {
  	  
  	  Optional<Product> optional = productRepository.findById(dealsForToday.getProductDTO().getProductId());
  	  Product product = optional.orElseThrow(()->new EKartException("Service.PRODUCT_NOT_FOUND"));
  	  
  	  Optional<Seller> optional1 = sellerRepository.findById(dealsForToday.getSellerDTO().getEmailId());
  	  Seller seller = optional1.orElseThrow(()->new EKartException("Service.SELLER_NOT_FOUND"));
  	  
  	  if(!(dealsForToday.getStartDate().toLocalDate().isEqual(dealsForToday.getEndDate().toLocalDate()) &&
  			  ChronoUnit.DAYS.between(LocalDate.now(),dealsForToday.getStartDate().toLocalDate())<30 &&
  			  dealsForToday.getEndDate().isAfter(dealsForToday.getStartDate())))
  	  {
  		  throw new EKartException("DealsForToday.INVALID_DETAILS");
  	  }
  			  
  	  DealsForToday dealForToday = new DealsForToday();
  	  dealForToday.setDealDiscount(dealsForToday.getDealDiscount());
  	  dealForToday.setEndDate(dealsForToday.getEndDate());
  	  dealForToday.setStartDate(dealsForToday.getStartDate());
  	  dealForToday.setSeller(seller);
  	  dealForToday.setProduct(product);
  	  
  	  deals.save(dealForToday);
  	  return dealForToday.getDealId();
  			  
  			  
    }
	@Override
	public List<DealsForTodayDTO> viewSellerDealsForToday(String sellerEmailId, Integer pageNo) throws EKartException {
	
		Pageable page=PageRequest.of(pageNo,10);
		List<DealsForToday>dealsForTodayList=deals.findBySellerEmailId(sellerEmailId, page);
		List<DealsForTodayDTO> dealsForTodayDTOList=new ArrayList<>();
		if(dealsForTodayList==null || dealsForTodayList.isEmpty())
		{
			throw new EKartException("DealsForToday.NO_DEALS_FOUND");
		}
		for(DealsForToday dealsForToday:dealsForTodayList)
		{
			DealsForTodayDTO dealsForTodayDTO=new DealsForTodayDTO();
			dealsForTodayDTO.setDealDiscount(dealsForToday.getDealDiscount());
			dealsForTodayDTO.setDealId(dealsForToday.getDealId());
			dealsForTodayDTO.setStartDate(dealsForToday.getStartDate());
			dealsForTodayDTO.setEndDate(dealsForToday.getEndDate());
				
			
			ProductDTO productDTO = new ProductDTO();
			productDTO.setBrand(dealsForToday.getProduct().getBrand());
			productDTO.setCategory(dealsForToday.getProduct().getCategory());
			productDTO.setDescription(dealsForToday.getProduct().getDescription());
		    productDTO.setDiscount(dealsForToday.getProduct().getDiscount());
			productDTO.setName(dealsForToday.getProduct().getName());
			productDTO.setProductId(dealsForToday.getProduct().getProductId());
			productDTO.setQuantity(dealsForToday.getProduct().getQuantity());
			productDTO.setPrice(dealsForToday.getProduct().getPrice());
			productDTO.setSellerEmailId(dealsForToday.getProduct().getEmailId());
			productDTO.setErrorMessage("error");
			productDTO.setSuccessMessage("success");
			dealsForTodayDTO.setProductDTO(productDTO);
			
			SellerDTO sellerDTO = new SellerDTO();
			sellerDTO.setName(dealsForToday.getSeller().getName());
			sellerDTO.setAddress(dealsForToday.getSeller().getAddress());
			sellerDTO.setPhoneNumber(dealsForToday.getSeller().getPhoneNumber());
			sellerDTO.setErrorMessage("error");
			sellerDTO.setEmailId(dealsForToday.getSeller().getEmailId());
			dealsForTodayDTO.setSellerDTO(sellerDTO);
			
			
			dealsForTodayDTOList.add(dealsForTodayDTO);
			
			
		}
		return dealsForTodayDTOList;
	}
	
	@Override
	public Integer removeProductFromDeals(Integer dealId) throws EKartException {
		// TODO Auto-generated method stub
		Optional<DealsForToday> optional = deals.findById(dealId);
		DealsForToday expiredDeal = optional.orElseThrow(()->new EKartException("DealsForToday.NO_DEALS_FOUND"));
		expiredDeal.setSeller(null);
		expiredDeal.setProduct(null);
		Integer id = expiredDeal.getDealId();
		deals.delete(expiredDeal);
		return id;
	}

}
