package com.infy.ekart.api;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.DealsForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.service.DealsForTodayService;

@CrossOrigin
@RestController
@RequestMapping(value="/deals")
public class DealsForTodayAPI {
	
	@Autowired
	private DealsForTodayService dealsForTodayService;
	
	@Autowired
	private Environment environment;
	
	Logger logger= LogManager.getLogger(DealsForTodayAPI.class.getName());
	
	
	@GetMapping(value="/withoutDeals/{sellerEmailId}/{pageNo}")
	public ResponseEntity<List<ProductDTO>> getProductWithoutDeals(@PathVariable String sellerEmailId, @PathVariable Integer pageNo) throws EKartException{
		return new ResponseEntity<>(dealsForTodayService.getProductsWithoutDeals(sellerEmailId, pageNo), HttpStatus.OK);
	}
	
	@PostMapping(value = "/addDeal")
	public ResponseEntity<String> addProductsTonewDeal(@Valid @RequestBody DealsForTodayDTO dealsForTodayDTO) throws EKartException {
		
		Integer dId = dealsForTodayService.addProductsTonewDeal(dealsForTodayDTO);
		String message = environment.getProperty("DealsForTodayAPI.PRODUCT_ADDED_TO_DEAL_SUCCESS")+dId;
		return new ResponseEntity<>(message, HttpStatus.CREATED);
	}
	@GetMapping(value="/sellerDealsForToday/{sellerEmailId}/{pageNo}")
	public ResponseEntity<List<DealsForTodayDTO>> viewSellerDealsForToday(@PathVariable String sellerEmailId,@PathVariable Integer pageNo) throws EKartException
	{
		return new ResponseEntity<>(dealsForTodayService.viewSellerDealsForToday(sellerEmailId, pageNo),HttpStatus.OK);
	}
	
	
}
